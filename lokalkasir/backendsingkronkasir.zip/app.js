const express = require('express');
const cors = require('cors');
const mysql = require('mysql'); // Driver wajib penghubung database cloud Hostinger
const app = express();

// Konfigurasi kapasitas data besar 50MB wajib ada
app.use(express.json({ limit: '50mb' })); 
app.use(cors()); // Mengizinkan akses dari frontend Linux lama Anda

// ISI SESUAI CATATAN NOTEPAD HOSTINGER ANDA
const dbConfigCloud = {
    host: 'localhost', 
    user: 'u461803074_hasan', 
    password: 'H4s4nmuhd0r!', 
    database: 'u461803074_db_kasirgm' 
};

const API_TOKEN = 'hasanganteng123';

// Fungsi memeriksa token keamanan menggunakan logika && (AND) yang benar
function cekTokenKeamanan(req, res, next) {
    const tokenDiterima = req.headers.authorization;
    if (!tokenDiterima || tokenDiterima !== 'Bearer ' + API_TOKEN) {
        console.log(`⚠️ [PERINGATAN] Ada kiriman data ilegal tanpa token yang sah!`);
        return res.status(401).json({ status: 'error', message: 'Token tidak valid / Unauthorized' });
    }
    next();
}

// ENDPOINT 1: Menerima Lemparan Data Omset & Menyimpan ke Database Cloud
app.post('/api/v1/sync-kasir/omset', cekTokenKeamanan, (req, res) => {
    const dataNota = req.body.data;
    const tokoPengirim = req.body.toko || 'TIDAK_DIKETAHUI';
    console.log(`\n=== [WEB] MENERIMA DATA OMSET DARI ${tokoPengirim} ===`);

    if (dataNota && dataNota.length > 0) {
        const connection = mysql.createConnection(dbConfigCloud);
        connection.connect((err) => {
            if (err) return console.error('❌ Gagal konek database cloud:', err.message);

            dataNota.forEach((nota) => {
                const queryInsert = `INSERT IGNORE INTO penjualan_cloud (id_nota, tanggal, operator, subtotal, jumlah) VALUES (?, ?, ?, ?, ?)`;
                connection.query(queryInsert, [nota.kode, nota.tanggal, nota.operator, nota.subtotal, nota.jumlah]);
            });
            console.log('✔ Seluruh data transaksi omset berhasil direkam permanen di cloud!');
            connection.end();
        });
    }
    res.status(200).json({ status: 'success', message: 'Data omset berhasil diolah di cloud' });
});

// ENDPOINT 2: Menerima Lemparan Cicilan Stok Barang & Metode "Upsert" di Cloud
app.post('/api/v1/sync-kasir/stok', cekTokenKeamanan, (req, res) => {
    const dataStok = req.body.data;
    const tokoPengirim = req.body.toko || 'TIDAK_DIKETAHUI';
    console.log(`\n=== [WEB] MENERIMA UPDATE STOK DARI ${tokoPengirim} ===`);
    console.log(`Total item barang yang di-update: ${dataStok ? dataStok.length : 0} item`);

    if (dataStok && dataStok.length > 0) {
        const connection = mysql.createConnection(dbConfigCloud);
        connection.connect((err) => {
            if (err) return console.error('❌ Gagal konek database cloud:', err.message);

            // Metode UPSERT: Update jika barang sudah ada, Insert jika barang belum ada
            dataStok.forEach((barang) => {
                const queryUpsert = `
                    INSERT INTO barang_cloud (kode_barang, nama_barang, stok_toko, stok_gudang, harga_beli, harga_jual) 
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE 
                    nama_barang = VALUES(nama_barang), stok_toko = VALUES(stok_toko), stok_gudang = VALUES(stok_gudang), harga_beli = VALUES(harga_beli), harga_jual = VALUES(harga_jual)
                `;
                connection.query(queryUpsert, [barang.kode, barang.nama, barang.toko, barang.gudang, barang.hpp, barang.harga_toko]);
            });
            console.log('✔ Pecahan data cicilan stok sukses diperbarui di database cloud!');
            connection.end();
        });
    }
    res.status(200).json({ status: 'success', message: 'Data stok berhasil diperbarui di cloud' });
});

app.listen(3000, () => {
    console.log('Website backend cloud berjalan di port 3000');
});
